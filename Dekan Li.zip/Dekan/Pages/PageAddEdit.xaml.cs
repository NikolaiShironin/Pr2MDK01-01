﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Dekan.Classes;

namespace Dekan.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddEdit.xaml
    /// </summary>
    public partial class PageAddEdit : Page
    {
        private Student _currentUser = new Student();
        public PageAddEdit(Student selectedUser)
        {
            InitializeComponent();

            CmbIDGroup.ItemsSource = DekanatEntities.GetContext().Group.ToList();
            CmbIDGroup.SelectedValuePath = "IDGroup";
            CmbIDGroup.DisplayMemberPath = "GroupName";

            if (selectedUser != null)
                _currentUser = selectedUser;
            DataContext = _currentUser;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentUser.FirstName))
                error.AppendLine("Укажите имя");
            if (string.IsNullOrWhiteSpace(_currentUser.LastName))
                error.AppendLine("Укажите фамилию");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentUser.IDStudent == 0)
                DekanatEntities.GetContext().Student.Add(_currentUser); //добавить в контекст
            try
            {
                DekanatEntities.GetContext().SaveChanges(); // сохранить изменения
                MessageBox.Show("Данные сохранены");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
